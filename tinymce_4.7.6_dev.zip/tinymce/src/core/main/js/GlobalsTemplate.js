export default tinymce.util.Tools.resolve('{$globalId}');
